#!/usr/bin/env python3
"""Acquire a public dataset when the project's own portal will not serve a machine.

Standard library only — no requests, no pandas. This runs inside headless coding-agent
subprocesses that may have nothing installed.

Four things this exists to do, none of which are specific to any one dataset:

1. ``probe`` reads the RESPONSE BODY. A blocked endpoint commonly answers 200 with an HTML
   verification or login page, so a status-code check reports success and the caller then
   parses HTML as JSON. Every wasted hour in this class starts there.
2. ``search`` / ``files`` resolve a dataset on an ARCHIVE host (figshare, Zenodo). Portals go
   down, get bot-walled, or move; the archive copy usually stays open, because serving
   machines is what an archive is for.
3. ``get`` streams a file to disk, and ``columns`` streams a wide matrix keeping only the
   columns you asked for — the matrices worth having are often 150-500 MB and you usually
   want twenty columns out of twenty thousand.
4. Everything records provenance: host, entry id, DOI, version, published date, the upstream
   checksum and one computed here. A number nobody can trace back to a released version is
   not evidence.

Usage:
  fetch_dataset.py probe   <url>
  fetch_dataset.py search  <host> <query> [--limit N]
  fetch_dataset.py files   <host> <entry_id>
  fetch_dataset.py get     <url> <dest> [--provenance FILE]
  fetch_dataset.py columns <url> <dest.csv> --keep GENE1,GENE2 [--provenance FILE]

Hosts: figshare, zenodo.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"
TIMEOUT = 60

# A body that is HTML when JSON/CSV was expected is the signature of a bot wall or a login
# redirect. These titles/markers are what such pages actually contain; matching the shape
# (HTML where data belongs) matters more than matching any single vendor's wording.
_WALL_MARKERS = (
    "verification", "checking your browser", "captcha", "cf-browser-verification",
    "attention required", "cloudflare", "enable javascript", "sign in", "log in",
    "access denied", "forbidden",
)


def _req(url: str, data: bytes | None = None, ctype: str | None = None) -> urllib.request.Request:
    headers = {"User-Agent": UA, "Accept": "application/json, text/csv, */*"}
    if ctype:
        headers["Content-Type"] = ctype
    return urllib.request.Request(url, data=data, headers=headers)


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat()


# --------------------------------------------------------------------------- probe

def probe(url: str) -> dict:
    """Is this endpoint actually usable? Reads the body; never trusts the status alone."""
    out = {"url": url, "checked_at": _utc()}
    try:
        with urllib.request.urlopen(_req(url), timeout=TIMEOUT) as r:
            status = r.status
            ctype = (r.headers.get("Content-Type") or "").lower()
            head = r.read(4096)
    except urllib.error.HTTPError as e:
        out.update({"ok": False, "status": e.code, "verdict": "http_error", "detail": str(e.reason)})
        return out
    except Exception as e:  # DNS, TLS, timeout
        out.update({"ok": False, "status": None, "verdict": "unreachable",
                    "detail": f"{type(e).__name__}: {e}"})
        return out

    text = head.decode("utf-8", errors="replace")
    low = text.lower()
    looks_html = low.lstrip().startswith(("<!doctype", "<html")) or "<html" in low[:512]

    if looks_html:
        marker = next((m for m in _WALL_MARKERS if m in low), None)
        title = re.search(r"<title[^>]*>(.*?)</title>", text, re.I | re.S)
        out.update({
            "ok": False,
            "status": status,
            "verdict": "blocked_html_body",
            "detail": (
                "status %s but the body is HTML"
                + (" containing %r" % marker if marker else "")
                + (" — <title>%s</title>" % title.group(1).strip() if title else "")
            ) % status,
            "hint": "the front door is closed to machines; look for an archive host "
                    "(see references/known_hosts.md)",
        })
        return out

    out.update({"ok": True, "status": status, "verdict": "usable",
                "content_type": ctype, "body_head": text[:200]})
    return out


# ------------------------------------------------------------------- archive hosts

def _figshare_search(query: str, limit: int) -> list[dict]:
    payload = json.dumps({"search_for": query, "page_size": limit}).encode()
    req = _req("https://api.figshare.com/v2/articles/search", data=payload,
               ctype="application/json")
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        rows = json.load(r)
    return [{"id": a.get("id"), "title": a.get("title"), "doi": a.get("doi"),
             "published": (a.get("published_date") or "")[:10]} for a in rows]


def _figshare_files(entry_id: str) -> dict:
    with urllib.request.urlopen(_req(f"https://api.figshare.com/v2/articles/{entry_id}"),
                                timeout=TIMEOUT) as r:
        art = json.load(r)
    return {
        "host": "figshare", "id": art.get("id"), "title": art.get("title"),
        "doi": art.get("doi"), "published": (art.get("published_date") or "")[:10],
        "files": [{"name": f.get("name"), "size": f.get("size"),
                   "url": f.get("download_url"), "md5": f.get("computed_md5")}
                  for f in (art.get("files") or [])],
    }


def _zenodo_search(query: str, limit: int) -> list[dict]:
    url = "https://zenodo.org/api/records?" + urllib.parse.urlencode(
        {"q": query, "size": limit, "sort": "mostrecent"})
    with urllib.request.urlopen(_req(url), timeout=TIMEOUT) as r:
        rows = (json.load(r) or {}).get("hits", {}).get("hits", [])
    return [{"id": a.get("id"), "title": (a.get("metadata") or {}).get("title"),
             "doi": a.get("doi"), "published": ((a.get("metadata") or {}).get("publication_date") or "")[:10]}
            for a in rows]


def _zenodo_files(entry_id: str) -> dict:
    with urllib.request.urlopen(_req(f"https://zenodo.org/api/records/{entry_id}"),
                                timeout=TIMEOUT) as r:
        rec = json.load(r)
    meta = rec.get("metadata") or {}
    return {
        "host": "zenodo", "id": rec.get("id"), "title": meta.get("title"),
        "doi": rec.get("doi"), "published": (meta.get("publication_date") or "")[:10],
        "files": [{"name": f.get("key"), "size": f.get("size"),
                   "url": (f.get("links") or {}).get("self"),
                   "md5": (f.get("checksum") or "").replace("md5:", "")}
                  for f in (rec.get("files") or [])],
    }


_HOSTS = {
    "figshare": (_figshare_search, _figshare_files),
    "zenodo": (_zenodo_search, _zenodo_files),
}

# Release entries are usually titled after the PRODUCT, while the FILE NAMES live in the
# entry's indexed content. Searching for a distinctive file name therefore finds release
# entries that a product-name search misses entirely — verified against a real archive where
# "<Product> <Version> Public" returned nothing and the file name returned every release.
SEARCH_NOTE = ("if a product-name query returns nothing, search for a distinctive FILE NAME "
               "from the dataset instead — file names are indexed with the entry's content")


# ------------------------------------------------------------------------ transfer

def _sha256_stream(fh) -> str:
    h = hashlib.sha256()
    for chunk in iter(lambda: fh.read(1 << 20), b""):
        h.update(chunk)
    return h.hexdigest()


def get(url: str, dest: str) -> dict:
    """Stream a file to disk. Refuses an HTML body — that is a wall, not the dataset."""
    p = probe(url)
    if not p["ok"]:
        return {"ok": False, "url": url, "dest": dest, "probe": p}
    os.makedirs(os.path.dirname(os.path.abspath(dest)) or ".", exist_ok=True)
    n = 0
    with urllib.request.urlopen(_req(url), timeout=TIMEOUT * 10) as r, open(dest, "wb") as out:
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            out.write(chunk)
            n += len(chunk)
    with open(dest, "rb") as fh:
        digest = _sha256_stream(fh)
    return {"ok": True, "url": url, "dest": dest, "bytes": n, "sha256": digest,
            "retrieved_at": _utc()}


_COL_RE = re.compile(r"^([A-Za-z0-9\-\._]+)\s*\(\d+\)$")


def _col_key(name: str) -> str:
    """Wide matrices often label columns ``SYMBOL (ID)``; match on the symbol."""
    m = _COL_RE.match(name.strip())
    return m.group(1) if m else name.strip()


def columns(url: str, dest: str, keep: list[str]) -> dict:
    """Stream a wide CSV, keeping only ``keep`` columns; write long format.

    The point is never to hold the whole matrix. A 500 MB release matrix becomes a few
    hundred KB when you want twenty columns, and nothing large touches the disk.
    """
    p = probe(url)
    if not p["ok"]:
        return {"ok": False, "url": url, "dest": dest, "probe": p}
    wanted = {k.strip() for k in keep if k.strip()}
    os.makedirs(os.path.dirname(os.path.abspath(dest)) or ".", exist_ok=True)
    kept: list[tuple[int, str]] = []
    row_label = "row_id"
    rows_out = 0
    with urllib.request.urlopen(_req(url), timeout=TIMEOUT * 30) as r, \
            open(dest, "w", newline="", encoding="utf-8") as out:
        writer = csv.writer(out)
        first = True
        buf = io.TextIOWrapper(r, encoding="utf-8", errors="replace", newline="")
        for line in buf:
            if not line.strip():
                continue
            fields = next(csv.reader([line]))
            if first:
                first = False
                row_label = fields[0] or "row_id"
                for i, name in enumerate(fields[1:], start=1):
                    if _col_key(name) in wanted:
                        kept.append((i, _col_key(name)))
                if not kept:
                    return {"ok": False, "url": url, "dest": dest,
                            "error": "none of the requested columns are in the header",
                            "header_sample": [_col_key(f) for f in fields[1:21]]}
                writer.writerow([row_label, "column", "value"])
                continue
            rid = fields[0]
            for i, name in kept:
                if i < len(fields) and fields[i] not in ("", "NA", "NaN", "nan"):
                    writer.writerow([rid, name, fields[i]])
                    rows_out += 1
    found = sorted({name for _, name in kept})
    return {"ok": True, "url": url, "dest": dest, "rows": rows_out,
            "columns_found": found,
            "columns_missing": sorted(wanted - set(found)),
            "retrieved_at": _utc()}


def record_provenance(path: str, entry: dict) -> None:
    """Append one line per acquisition. A dataset without this is an unciteable number."""
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry, ensure_ascii=False) + "\n")


# ---------------------------------------------------------------------------- cli

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("probe"); s.add_argument("url")
    s = sub.add_parser("search"); s.add_argument("host", choices=sorted(_HOSTS))
    s.add_argument("query"); s.add_argument("--limit", type=int, default=25)
    s = sub.add_parser("files"); s.add_argument("host", choices=sorted(_HOSTS))
    s.add_argument("entry_id")
    s = sub.add_parser("get"); s.add_argument("url"); s.add_argument("dest")
    s.add_argument("--provenance")
    s = sub.add_parser("columns"); s.add_argument("url"); s.add_argument("dest")
    s.add_argument("--keep", required=True); s.add_argument("--provenance")

    a = ap.parse_args(argv)
    if a.cmd == "probe":
        out = probe(a.url)
    elif a.cmd == "search":
        out = {"host": a.host, "query": a.query, "note": SEARCH_NOTE,
               "results": _HOSTS[a.host][0](a.query, a.limit)}
    elif a.cmd == "files":
        out = _HOSTS[a.host][1](a.entry_id)
    elif a.cmd == "get":
        out = get(a.url, a.dest)
        if a.provenance and out.get("ok"):
            record_provenance(a.provenance, out)
    else:
        out = columns(a.url, a.dest, a.keep.split(","))
        if a.provenance and out.get("ok"):
            record_provenance(a.provenance, out)

    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0 if out.get("ok", True) else 1


if __name__ == "__main__":
    sys.exit(main())
